/*
 * CMake configuration file, do not modify
 */

#ifndef VERSION_H
#define VERSION_H

#define VERSION "1.0.1"

#endif
